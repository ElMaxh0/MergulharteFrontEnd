import { useState } from "react";
import { Terms } from "../Conteudos/TermosDeUso/terms";

function UseLicense(int){
    
}
export{
    UseLicense
}